
public class Main {

	public static void main(String[] args) {

		float[] tabela = {0,0,1};

		
		Perceptron perceptron = new Perceptron(tabela[0],tabela[1],1,1,0,1,1);
		System.out.println("valor somat�ria: "+perceptron.somatoria());
		System.out.println("valor do erro: " + perceptron.erro(1));
		System.out.println("novo peso do n1: " + perceptron.pesonovo(1, 0, 1));
	}

}
