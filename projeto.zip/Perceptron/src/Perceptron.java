
public class Perceptron {

	float n1, n2;
	float peson1, peson2, pesobias;
	float txaprend;

	float bias;

	public Perceptron(float n1, float n2, float peson1, float peson2, float pesobias, float txaprend,
			float bias) {
		this.n1 = n1;
		this.n2 = n2;
		this.peson1 = peson1;
		this.peson2 = peson2;
		this.pesobias = pesobias;
		this.txaprend = txaprend;

		this.bias = bias;
	}

	public float somatoria() {

		return (bias * pesobias) + (n1 * peson1) + (n2 * peson2);
	}

	public float erro(float valoresperado) {

		return valoresperado - somatoria();
	}

	public float pesonovo(float pesoanterior, float nentrada, float valoresperado) {

		return pesoanterior + (erro(valoresperado) * txaprend * nentrada);
	}

}
