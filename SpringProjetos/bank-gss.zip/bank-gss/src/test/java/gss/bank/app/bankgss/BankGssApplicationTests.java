package gss.bank.app.bankgss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankGssApplicationTests {

	@Test
	void contextLoads() {
	}

}
