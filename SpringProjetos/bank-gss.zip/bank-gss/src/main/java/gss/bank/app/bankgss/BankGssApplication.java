package gss.bank.app.bankgss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankGssApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankGssApplication.class, args);
	}

}
